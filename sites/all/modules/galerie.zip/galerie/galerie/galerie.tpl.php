<div class="galerie-wrapper galerie-<?php echo $galerie_type ?>">
  <div class="galerie-browser-wrapper">
    <div class="galerie-browser">
      <?php echo $thumbnails ?>
    </div>
    <div class="galerie-browser-more">
      <?php echo $more_link ?>
    </div>
  </div>
  <div class="galerie-viewer-wrapper">
    <div class="galerie-viewer">
      <?php echo $image ?>
    </div>
  </div>
</div>
